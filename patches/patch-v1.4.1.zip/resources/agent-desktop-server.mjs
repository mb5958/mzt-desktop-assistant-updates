import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { execFile, execSync, spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.AD_RULE_PORT || 8730);
const HTML_FILE = path.join(__dirname, 'agent-desktop-rule-builder.html');
// 数据目录：桌面版（portable）会传 AD_DATA_DIR 指向用户目录，避免每次解压到临时目录丢数据
const DATA_DIR = process.env.AD_DATA_DIR || __dirname;
try { if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true }); } catch (e) {}
const RULES_FILE = path.join(DATA_DIR, 'rules.json');
const TEMPLATES_FILE = path.join(DATA_DIR, 'templates.json');
// 版本号唯一来源是打包时的 package.json 版本：主进程通过 APP_VERSION 环境变量传进来
const APP_VERSION = process.env.APP_VERSION || '1.2.0';

// 微信文字消息模板（用户自己保存的；内置模板在前端，不进这里）
let templates = [];
try {
  if (fs.existsSync(TEMPLATES_FILE)) templates = JSON.parse(fs.readFileSync(TEMPLATES_FILE, 'utf8')) || [];
  if (!Array.isArray(templates)) templates = [];
} catch (e) { templates = []; }
function saveTemplates() {
  try { fs.writeFileSync(TEMPLATES_FILE, JSON.stringify(templates, null, 2)); } catch (e) {}
}

function resolveAdBinary() {
  const env = process.env.AGENT_DESKTOP_PATH;
  if (env && fs.existsSync(env)) return env;
  try {
    const root = execSync('npm root -g', { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim();
    if (root) {
      const names = ['agent-desktop-win32-x64.exe', 'agent-desktop-win32-arm64.exe', 'agent-desktop.exe', 'agent-desktop-darwin', 'agent-desktop-linux'];
      for (const n of names) {
        const p = path.join(root, 'agent-desktop', 'bin', n);
        if (fs.existsSync(p)) return p;
      }
    }
  } catch (e) {}
  return 'agent-desktop';
}
const AD = resolveAdBinary();

// 常见应用的完整路径解析（agent-desktop launch 裸名只在系统目录查找）
function resolveAppPath(name) {
  if (!name) return name;
  const key = name.toLowerCase().replace(/\.exe$/, '');
  const candidates = [];
  if (key === 'weixin' || key === 'wechat') {
    candidates.push(
      'C:\\Program Files\\Tencent\\Weixin\\Weixin.exe',
      'C:\\Program Files (x86)\\Tencent\\Weixin\\Weixin.exe',
      'C:\\Program Files\\Tencent\\WeChat\\WeChat.exe',
      'C:\\Program Files (x86)\\Tencent\\WeChat\\WeChat.exe'
    );
  }
  for (const p of candidates) {
    if (fs.existsSync(p)) return p;
  }
  return name;
}

/* 解析 .lnk 快捷方式指向的目标程序 exe 路径（纯 Node 读取二进制里的路径字符串） */
const lnkCache = new Map();
function resolveLnkTarget(lnkPath) {
  if (lnkCache.has(lnkPath)) return lnkCache.get(lnkPath);
  let target = null;
  try {
    const buf = fs.readFileSync(lnkPath);
    const asc = buf.toString('latin1');
    const m = asc.match(/[A-Za-z]:[\\/][^\u0000\r\n]{0,200}?\.exe/ig);
    if (m && m.length) target = m[0];
  } catch (e) {}
  lnkCache.set(lnkPath, target);
  return target;
}

/* 把 .lnk / 完整路径 转成可用于匹配窗口的关键词（.lnk 会先解析目标程序） */
const kwCache = new Map();
function windowKeyword(app) {
  if (!app) return '';
  let base = String(app).trim();
  if (kwCache.has(base)) return kwCache.get(base);
  const raw = base;
  if (/\.lnk$/i.test(base) && fs.existsSync(base)) {
    const t = resolveLnkTarget(base);
    if (t) base = t;
  }
  if (/[\\/]/.test(base) || /\.(lnk|exe)$/i.test(base)) {
    base = base.split(/[\\/]/).pop() || base;
    base = base.replace(/\.(lnk|exe)$/i, '');
  }
  kwCache.set(raw, base);
  return base;
}

/* 按关键词（应用名或窗口标题）找到窗口对象 */
async function findWindowByKeyword(kw) {
  if (!kw) return null;
  try {
    const r = await runCmd(AD, ['list-windows'], 8000);
    const j = parseJson(r.stdout);
    const wins = (j && j.data) || [];
    const k = String(kw).toLowerCase();
    return wins.find(w => {
      const an = String(w.app_name || '').toLowerCase();
      const ti = String(w.title || '').toLowerCase();
      return (an && an.indexOf(k) >= 0) || (ti && ti.indexOf(k) >= 0);
    }) || null;
  } catch (e) { return null; }
}

/* ============ 规则持久化 ============ */
function loadRules() {
  try {
    if (fs.existsSync(RULES_FILE)) {
      const data = JSON.parse(fs.readFileSync(RULES_FILE, 'utf8'));
      if (Array.isArray(data)) return data;
    }
  } catch (e) { console.error('[rules] load error', e.message); }
  return [];
}
function saveRules() {
  try { fs.writeFileSync(RULES_FILE, JSON.stringify(rules, null, 2)); }
  catch (e) { console.error('[rules] save error', e.message); }
}

let rules = loadRules();

/* ============ 日志 ============ */
const logs = {}; // ruleId -> array
function addLog(ruleId, entry) {
  if (!logs[ruleId]) logs[ruleId] = [];
  logs[ruleId].push(entry);
  if (logs[ruleId].length > 500) logs[ruleId].shift();
}

/* ============ 命令执行 ============ */
function runCmd(cmd, args, timeout = 30000) {
  return new Promise((resolve) => {
    execFile(cmd, args, { timeout, maxBuffer: 20 * 1024 * 1024, windowsHide: true },
      (err, stdout, stderr) => {
        resolve({
          ok: !err,
          code: err ? (err.code == null ? -1 : err.code) : 0,
          stdout: (stdout || '').trim(),
          stderr: (stderr || '').trim()
        });
      });
  });
}

function parseJson(text) {
  try { return JSON.parse(text); } catch (e) { return null; }
}

/* 从 find/snapshot 返回中容错提取 ref */
function extractRef(stdout) {
  const j = parseJson(stdout);
  if (!j) return null;
  const grab = (o) => {
    if (o == null) return null;
    if (typeof o === 'string') return /^@/.test(o) ? o : null;
    if (Array.isArray(o)) {
      for (const x of o) { const r = grab(x); if (r) return r; }
      return null;
    }
    if (typeof o === 'object') {
      for (const k of ['ref_id', 'ref', 'id']) {
        if (o[k] && typeof o[k] === 'string' && o[k].startsWith('@')) return o[k];
      }
      for (const k of Object.keys(o)) {
        if (k === 'data' || k === 'tree' || k === 'matches' || k === 'elements' || k === 'children') {
          const r = grab(o[k]); if (r) return r;
        }
      }
      return null;
    }
    return null;
  };
  return grab(j.data !== undefined ? j.data : j);
}

/* 角色权重：网页内真正的可点击项优先，浏览器工具栏按钮/静态文本降级 */
function roleScore(role) {
  const r = (role || '').toLowerCase();
  if (r === 'link') return 40;
  if (['option', 'tab', 'tabitem', 'menuitem', 'button', 'listitem', 'treeitem', 'checkbox', 'radio'].indexOf(r) >= 0) return 25;
  if (r === 'menubutton') return 3;            // 多为浏览器工具栏/扩展按钮，降级但不排除
  if (r === 'statictext' || r === 'text') return -500; // 不可点击
  return 5;
}

/* 名称归一化：剥离“未读角标”等装饰，让匹配只认文字本身。
   角标数字会动态变化（如「4 省内」「315 OA待阅」「12 · 待办」），绝不能作为识别依据。
   规则：去掉所有空白 → 去掉开头的数字角标（含其后的分隔符）→ 去掉结尾的数字角标。 */
function normName(s) {
  let t = String(s || '').trim().replace(/\s+/g, '');
  // 前导角标： "4省内"→"省内"，"315OA待阅"→"OA待阅"，"12·待办"→"待办"
  t = t.replace(/^\d+\s*[\.、·,，:：\-—|]?\s*/, '');
  // 尾随角标： "待办(3)"→"待办"，"消息5"→"消息"
  t = t.replace(/\s*[\(\[（【]?\d+[\)\]）】]?$/, '');
  return t;
}

/* 名称匹配档位：归一化后精确 > 前缀 > 包含。精确档权重压倒角色/URL，避免角标造成平局误选。 */
function nameScore(rawName, query) {
  const q = normName(query);
  if (!q) return 0;
  const n = normName(rawName);
  if (!n) return -100;
  if (n === q) return 200;                 // 精确（剥离角标后完全相等）
  if (n.indexOf(q) === 0) return 60;        // 前缀（如查“OA”命中“OA待阅”）
  if (n.indexOf(q) >= 0) return 20;         // 包含
  if (q.indexOf(n) === 0) return 10;        // 反向：元素名是查询的前缀
  return -40;                               // 不相关，重罚
}

/* 从 find 结果里挑选“最该点”的那个 ref（通用逻辑，不针对任何特定软件/页面）：
   先按名称匹配度分档（精确优先，已剥离角标），再在同档内按“真实链接 > 交互项 > 工具栏按钮 > 静态文本”择优。
   allowWeak=false 时排除 menubutton（浏览器工具栏/扩展按钮）：页面还在加载时 find 往往只返回
   工具栏按钮，这时应视为“还没找到”继续轮询等页面渲染完，而不是把工具栏按钮点出去把界面带跑偏。 */
function pickRef(stdout, query, allowWeak) {
  const m = pickMatch(stdout, query, allowWeak);
  return m ? m.ref : null;
}

/* pickRef 的增强版：返回选中匹配的完整信息 { ref, name, role }，供日志显示“点了什么” */
function pickMatch(stdout, query, allowWeak) {
  const j = parseJson(stdout);
  if (!j) return null;
  const data = j.data !== undefined ? j.data : j;
  const matches = (data && data.matches) || [];
  if (Array.isArray(matches) && matches.length) {
    let best = null, bestScore = -Infinity;
    for (const m of matches) {
      const ref = m.ref_id || m.ref || m.id;
      if (!ref || typeof ref !== 'string' || !ref.startsWith('@')) continue; // 跳过不可点（无 ref）
      const role = String(m.role || '').toLowerCase();
      if (!allowWeak && role === 'menubutton') continue; // 非最后一轮：不考虑工具栏按钮
      let s = nameScore(m.name, query) * 10;   // 名称匹配是第一决定因素
      s += roleScore(role);
      const val = m.value;
      if (typeof val === 'string' && /^https?:\/\//i.test(val)) s += 100;    // 真实链接，最高优先
      else if (val) s += 20;
      if (m.interactive === true) s += 10;
      if (s > bestScore) { bestScore = s; best = { ref, name: String(m.name || '').trim(), role, score: s }; }
    }
    // 防线：只有“相关”的匹配才可用。全部不相关（如页面根本没这个菜单）时返回 null，
    // 让 locateRef 按“未找到”处理，而不是硬点一个不相关元素把界面带跑偏。
    if (best && best.score > 0) return best;
    return null;
  }
  const fallback = extractRef(stdout);
  return fallback ? { ref: fallback, name: '', role: '', score: 1 } : null;
}

/* ============ 动态变量模板渲染 ============ */
async function getClipboard() {
  const r = await runCmd(AD, ['clipboard-get'], 10000);
  if (r.ok) {
    const j = parseJson(r.stdout);
    if (j) {
      const d = j.data;
      if (typeof d === 'string') return d;
      if (d && (d.value || d.text)) return d.value || d.text;
    }
    return r.stdout;
  }
  return '';
}

async function getWeather(city) {
  if (!city) return '未指定城市';
  try {
    const url = 'https://wttr.in/' + encodeURIComponent(city) + '?format=%c+%t+%h&m';
    const r = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (r.ok) { const t = (await r.text()).trim(); if (t) return t; }
  } catch (e) {}
  try {
    const url2 = 'https://wttr.in/' + encodeURIComponent(city) + '?format=3';
    const r2 = await fetch(url2, { signal: AbortSignal.timeout(8000) });
    if (r2.ok) { const t = (await r2.text()).trim(); if (t) return t; }
  } catch (e) {}
  return '天气获取失败';
}

function latestFile(dir) {
  try {
    if (!dir || !fs.existsSync(dir)) return '目录不存在';
    const files = fs.readdirSync(dir).filter(f => { try { return fs.statSync(path.join(dir, f)).isFile(); } catch (e) { return false; } });
    if (!files.length) return '目录为空';
    files.sort((a, b) => fs.statSync(path.join(dir, b)).mtimeMs - fs.statSync(path.join(dir, a)).mtimeMs);
    return path.join(dir, files[0]);
  } catch (e) { return '目录读取失败'; }
}

function listFiles(dir) {
  try {
    if (!dir || !fs.existsSync(dir)) return '目录不存在';
    const files = fs.readdirSync(dir).filter(f => { try { return fs.statSync(path.join(dir, f)).isFile(); } catch (e) { return false; } });
    return files.join('、') || '目录为空';
  } catch (e) { return '目录读取失败'; }
}

function formatCnDate(d) {
  return d.getFullYear() + '年' + (d.getMonth() + 1) + '月' + d.getDate() + '日';
}
function formatCnTime(d) {
  const h = d.getHours(), m = d.getMinutes();
  // 时段按用户约定：8点前凌晨 / 8-12上午 / 12-14中午 / 14-18下午 / 18-20傍晚 / 20点后晚上
  // 时间用 24 小时制（如「晚上22:15」，不是「下午10点15分」）
  const period = h < 8 ? '凌晨' : h < 12 ? '上午' : h < 14 ? '中午' : h < 18 ? '下午' : h < 20 ? '傍晚' : '晚上';
  return period + String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
}

let currentSendIndex = 0; // 当前发送序号（多联系人/重复发送时，第几次）
let currentContactName = ''; // 当前正在发送的联系人/群名（供 {{name}} 称谓变量渲染）

async function resolveVar(expr) {
  const idx = expr.indexOf(':');
  const name = idx >= 0 ? expr.slice(0, idx).trim() : expr.trim();
  const arg = idx >= 0 ? expr.slice(idx + 1) : '';
  const now = new Date();
  switch (name) {
    case 'now': return formatCnDate(now) + ' ' + formatCnTime(now);
    case 'date': return formatCnDate(now);
    case 'time': return formatCnTime(now);
    case 'weekday': return ['日', '一', '二', '三', '四', '五', '六'][now.getDay()];
    case 'count': return String(currentSendIndex || 1);
    // 对方称谓：当前正在发送的联系人/群名（逐个联系人渲染，所以多人时各自不同）
    case 'name':
    case 'contact':
    case '昵称':
    case '称呼': return currentContactName || '您';
    case 'random': return String(Math.floor(Math.random() * 1000000));
    case 'clipboard': return await getClipboard();
    case 'weather': return await getWeather(arg);
    case 'latest-file': return latestFile(arg);
    case 'file-list': return listFiles(arg);
    case 'env': return process.env[arg] || '';
    default: return '{{' + expr + '}}';
  }
}

async function renderText(text) {
  const re = /\{\{\s*([^{}]+?)\s*\}\}/g;
  const matches = [...text.matchAll(re)];
  if (!matches.length) return text;
  let out = text;
  for (const m of matches) {
    out = out.replace(m[0], await resolveVar(m[1]));
  }
  return out;
}

/* ============ 命令翻译层 ============ */
const LOCATOR_FLAG = { name: '--name', role: '--role', text: '--text', id: '--native-id' };

/* 获取当前前台（聚焦）窗口 */
async function getFocusedWindow() {
  try {
    const r = await runCmd(AD, ['list-windows'], 8000);
    const j = parseJson(r.stdout);
    const wins = (j && j.data) || [];
    return wins.find(w => w.is_focused) || null;
  } catch (e) { return null; }
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

/* 判断字符串是否像一个网址：地址栏经常省略 http:// 前缀
   （如 "gcfz.mss.ctc.com:12157/contract/..."），所以不能只认带协议头的。 */
function looksLikeUrl(v) {
  if (typeof v !== 'string') return false;
  const s = v.trim();
  if (!s || s.length < 4) return false;
  if (/^[a-z][a-z0-9+.\-]*:\/\//i.test(s)) return true;      // http:// https:// ftp://
  if (s.indexOf(' ') >= 0) return false;                     // 含空格 → 像搜索词而非网址
  return /^[\w\-]+(\.[\w\-]+)+(:\d+)?([\/?#].*)?$/i.test(s)  // 域名(:端口)(/路径)
      || /^(\d{1,3}\.){3}\d{1,3}(:\d+)?([\/?#].*)?$/.test(s); // IP(:端口)(/路径)
}

/* ============ 页面锚定校验（浏览器场景通用） ============
   若任务里配置了锚点（locator.pageUrl / pageTitle），执行前先确认浏览器还停在目标页面：
   1. 当前标签就是目标页 → 直接继续
   2. 浏览器里有别的目标页标签（按标签文字/标题识别）→ 自动点击切换过去
   3. 都没有 → 在【同一个浏览器窗口】里新开标签页（ctrl+t，新标签页地址栏自动聚焦）输入网址回车
   全程只在目标浏览器窗口内操作，绝不借用系统默认浏览器（避免跳到 Edge/Chrome）。 */

/* 取网址的站点部分（协议+主机+端口），用于“同站”判断。 */
function siteOf(u) {
  return String(u || '').trim().toLowerCase().replace(/^[a-z][a-z0-9+.\-]*:\/\//, '').split(/[/?#]/)[0];
}

/* 路径级 URL 比对：剥掉协议头和结尾分隔符后互相包含即算同一页面。
   SPA 子页面（如 #/app/works/read）与锚点（#/app/information）同站但不同页，必须能区分。 */
function urlPathEq(a, b) {
  const strip = (u) => String(u || '').trim().toLowerCase().replace(/^[a-z][a-z0-9+.\-]*:\/\//, '').replace(/[#/]+$/, '');
  const x = strip(a), y = strip(b);
  return !!(x && y && (x === y || x.indexOf(y) === 0 || y.indexOf(x) === 0));
}

/* 当前前台窗口是否就是指定窗口（发物理按键前必须验证，防止把按键送进别的程序） */
async function isForeground(winId) {
  try {
    const r = await runCmd(AD, ['list-windows'], 8000);
    const j = parseJson(r.stdout);
    const w = ((j && j.data) || []).find(x => x.id === winId);
    return !!(w && w.is_focused);
  } catch (e) { return false; }
}

/* 可靠聚焦窗口：先恢复最小化，再用 --headed 物理聚焦（企业浏览器对语义聚焦常拒绝） */
async function focusWindowHard(winId) {
  try {
    await runCmd(AD, ['restore', '--window-id', winId], 6000);
    for (let i = 0; i < 3; i++) {
      const r = await runCmd(AD, ['focus-window', '--window-id', winId, '--headed'], 8000);
      if (r.ok && await isForeground(winId)) { await sleep(400); return true; }
      await sleep(600);
    }
  } catch (e) {}
  return false;
}

/*  guarded 物理按键：只有目标窗口确认在前台才发送，否则拒绝执行。
   这是防“把网址粘进别的程序（如 WorkBuddy）并回车”的硬性防线。 */
async function pressInWindow(winId, keys) {
  if (!await isForeground(winId)) return false;
  const r = await runCmd(AD, ['press', '--headed', keys], 5000);
  return r.ok;
}

/* 读取某窗口的地址栏当前网址（找不到返回 null） */
async function readAddressBar(winId) {
  try {
    const fr = await runCmd(AD, ['find', '--window-id', winId, '--role', 'textfield', '--timeout-ms', '8000'], 16000);
    const fj = parseJson(fr.stdout);
    const fields = ((fj && fj.data && fj.data.matches) || []);
    const addr = fields.find(f => typeof f.value === 'string' && looksLikeUrl(f.value));
    return addr ? String(addr.value) : null;
  } catch (e) { return null; }
}

/* 列出窗口里所有标签页（通用：靠无障碍树 role=tab/tabitem，不依赖具体浏览器）
   返回 [{ ref, name, selected }]，selected 表示是否当前活动标签。 */
async function listTabs(winId) {
  try {
    const sr = await runCmd(AD, ['snapshot', '--window-id', winId, '--compact', '--timeout-ms', '8000'], 20000);
    const sj = parseJson(sr.stdout);
    if (!sj || !sj.ok || !sj.data || !sj.data.tree) return [];
    const tabs = [];
    const walk = (n) => {
      if (!n) return;
      const role = String(n.role || '').toLowerCase();
      if ((role === 'tab' || role === 'tabitem') && n.ref_id) {
        const states = n.states || [];
        const selected = states.indexOf('selected') >= 0 || states.indexOf('focused') >= 0 || n.selected === true;
        tabs.push({ ref: n.ref_id, name: String(n.name || '').trim(), selected });
      }
      (n.children || []).forEach(walk);
    };
    walk(sj.data.tree);
    return tabs;
  } catch (e) { return []; }
}

/* 判断窗口当前是否已停在目标页（标题命中 或 地址栏 URL 同站/同路径） */
async function atTargetPage(winId, titleKw, urlAnchor, anchorSite) {
  const lr = await runCmd(AD, ['list-windows'], 8000);
  const lj = parseJson(lr.stdout);
  const w = ((lj && lj.data) || []).find(x => x.id === winId);
  const title = String((w && w.title) || '');
  if (titleKw && title.indexOf(titleKw) >= 0) return true;
  const u = await readAddressBar(winId);
  if (u && urlPathEq(u, urlAnchor)) return true;
  if (u && anchorSite && siteOf(u) === anchorSite) return true;
  return false;
}

/* 智能切换到目标标签（通用、抗干扰）：
   1. 枚举所有标签；2. 按“标题匹配度”给候选排序（精确>包含>其它非空白标签）；
   3. 逐个点击候选并【验证】是否真的到达目标页，命中即返回；
   4. 已选中的标签跳过（点了也不会变）。
   这样无论有几个同名标签、是否有空白页/其它页面干扰，都能试到正确的那个。 */
async function switchToTargetTab(winId, titleKw, urlAnchor, anchorSite) {
  const tabs = await listTabs(winId);
  if (!tabs.length) return false;
  const isBlank = (nm) => !nm || /^(新标签页|新建标签页|new tab|空白|about:blank)$/i.test(nm);
  // 候选打分：标题含关键词最高，其次非空白标签兜底（有些站点标签名可能与 pageTitle 不完全一致）
  const score = (t) => {
    if (isBlank(t.name)) return -1;
    if (titleKw && t.name.indexOf(titleKw) >= 0) return 100;
    return 1; // 其它已打开的标签也作为兜底候选（可能标题变了但其实是目标站）
  };
  const candidates = tabs
    .filter(t => !t.selected) // 已选中的不用点
    .map(t => ({ t, s: score(t) }))
    .filter(x => x.s >= 0)
    .sort((a, b) => b.s - a.s);

  for (const { t } of candidates) {
    const cr = await runCmd(AD, ['click', t.ref], 8000);
    if (!cr.ok) continue;
    await sleep(2000); // 等标签切换渲染
    if (await atTargetPage(winId, titleKw, urlAnchor, anchorSite)) {
      return t.name || true;
    }
  }
  return false;
}

/* 在当前活动标签内直接导航到目标网址（复用当前标签，避免无脑新开）：
   聚焦地址栏 → 全选 → 粘贴网址 → 回车 → 轮询验证。
   地址栏聚焦快捷键按可靠性依次尝试：ctrl+l（Chrome/Edge/Firefox 通用）→ alt+d → F6（焦点循环，
   部分企业安全浏览器屏蔽 ctrl+l，实测 Molan 只有 F6 有效）。
   每次物理按键前都验证目标窗口在前台，失败立即安全中止。成功返回 true。 */
async function navigateInCurrentTab(winId, fullUrl, titleKw, urlAnchor, anchorSite) {
  await runCmd(AD, ['clipboard-set', fullUrl], 5000);
  for (const focusKey of ['ctrl+l', 'alt+d', 'F6']) {
    if (!await pressInWindow(winId, focusKey)) return false; // 失去前台，安全中止
    await sleep(600);
    if (!await pressInWindow(winId, 'ctrl+a')) return false;  // 全选地址栏原内容
    await sleep(150);
    if (!await pressInWindow(winId, 'ctrl+v')) return false;  // 粘贴目标网址
    await sleep(400);
    if (!await pressInWindow(winId, 'return')) return false;  // 回车导航
    for (let i = 0; i < 4; i++) {
      await sleep(2000);
      if (await atTargetPage(winId, titleKw, urlAnchor, anchorSite)) return true;
    }
    // 这种方式没到目标页，换下一个地址栏聚焦快捷键再试
  }
  return false;
}

/* 通用“这是个浏览器窗口吗”检测：窗口内存在地址栏类输入框（名称含 地址/网址/address/location/search）
   即视为浏览器——Chrome/Edge/Firefox/各国产 Chromium 壳浏览器都暴露此特征，不依赖浏览器名单。
   新标签页地址栏值为空也能检出（看的是控件名，不是值）。 */
async function looksLikeBrowserWindow(winId) {
  try {
    const fr = await runCmd(AD, ['find', '--window-id', winId, '--role', 'textfield', '--timeout-ms', '6000'], 14000);
    const fj = parseJson(fr.stdout);
    const fields = ((fj && fj.data && fj.data.matches) || []);
    return fields.some(f => /地址|网址|address|location|search|搜索/i.test(String(f.name || '')) || looksLikeUrl(f.value));
  } catch (e) { return false; }
}

async function ensurePage(loc, ruleId, seq) {
  const urlAnchor = String((loc && loc.pageUrl) || '').trim();
  if (!urlAnchor) return { ok: true };
  const titleAnchor = String((loc && loc.pageTitle) || '').trim();
  const fullUrl = /^[a-z][a-z0-9+.\-]*:\/\//i.test(urlAnchor) ? urlAnchor : 'http://' + urlAnchor;
  const appKey = windowKeyword(loc.app || '').toLowerCase();
  const anchorSite = siteOf(urlAnchor);

  // 标签/窗口标题关键词：优先用户填的 pageTitle（即网页 <title> 文字）
  const titleKw = titleAnchor;

  try {
    const lr = await runCmd(AD, ['list-windows'], 8000);
    const lj = parseJson(lr.stdout);
    const wins = (lj && lj.data) || [];

    // ── 第 1 步：确定【目标浏览器窗口】——绝不允许操作到别的程序 ──
    // 通用判定优先级：① locator.app 指定的应用（最可靠，建议填）
    //   ② 窗口标题含 pageTitle 关键词（强信号：就是目标页的窗口）
    //   ③ 当前前台窗口且是浏览器（排除助手自己）——注意排在标题匹配之后：
    //      静默后台执行时前台可能是用户正在用的其它浏览器，不能劫持它
    //   ④ 第一个具备浏览器特征的窗口
    const selfApp = path.basename(process.execPath || '', '.exe').toLowerCase(); // 助手自己的进程名，防把自己当浏览器
    let target = null;
    if (appKey) {
      target = wins.find(w => String(w.app_name || '').toLowerCase().indexOf(appKey) >= 0) || null;
    }
    if (!target && titleKw) {
      target = wins.find(w => String(w.title || '').indexOf(titleKw) >= 0) || null;
    }
    if (!target) {
      const fw = wins.find(w => w.is_focused);
      if (fw && String(fw.app_name || '').toLowerCase().indexOf(selfApp) < 0 && await looksLikeBrowserWindow(fw.id)) target = fw;
    }
    if (!target) {
      // 兜底扫描：最小化窗口也纳入（语义操作不依赖前台），但排在可见窗口之后
      const scanOrder = wins.filter(w => !w.minimized).concat(wins.filter(w => w.minimized));
      for (const w of scanOrder) {
        if (String(w.app_name || '').toLowerCase().indexOf(selfApp) >= 0) continue;
        if (await looksLikeBrowserWindow(w.id)) { target = w; break; }
      }
    }
    if (!target) return { ok: false, err: '页面锚定失败：找不到目标浏览器窗口（建议在「在哪个软件里」填应用名，如 molan126）' };
    // 登记窗口原状态（即使这轮不需要唤醒也登记）：
    // 有些浏览器在页面跳转时会自己把窗口从最小化恢复出来，任务结束时要能缩回去
    noteWoken(ruleId, target.id, !!target.minimized);

    // ── 静默模式核心原则 ──
    // 语义操作（snapshot/find/click via ref）在窗口最小化时照样可用且不抢焦点；
    // 物理按键（press --headed）必须窗口在前台。因此：
    //   能语义完成的（切标签/点元素）→ 全程静默，窗口保持原状（含最小化）；
    //   必须物理按键的（地址栏导航）→ 临时唤醒，用完恢复原最小化状态。
    const wasMinimized = !!target.minimized;

    // ── 第 2 步：当前活动标签就是目标页？（语义读取，最小化也能判断）──
    const curUrl = await readAddressBar(target.id);
    const titleHit = titleKw && String(target.title || '').indexOf(titleKw) >= 0;
    if (titleHit || (curUrl && urlPathEq(curUrl, urlAnchor))) {
      return { ok: true, action: 'same-tab', title: target.title, winId: target.id, wasMinimized };
    }

    // ── 第 3 步：不在目标页 → 必须先唤醒窗口（硬约束，不是优化）──
    // 原因：标签栏属于浏览器外壳，最小化/后台时点不动；地址栏导航也要物理按键。
    // 所以"偏离目标页"的修复动作必然短暂唤醒窗口，操作完立刻缩回原状态。
    noteWoken(ruleId, target.id, wasMinimized); // 登记：任务结束/出错时统一还原
    addLog(ruleId, {
      time: Date.now(), seq, step: 'ensure-page', ok: true,
      desc: '页面锚定：临时把窗口带到前台',
      output: wasMinimized ? '窗口原本是最小化的，操作完成后会自动缩回' : '窗口原本就显示着'
    });
    if (!await focusWindowHard(target.id)) {
      // 注意：focusWindowHard 内部会先 restore，所以哪怕聚焦失败，窗口也可能已经被拽到屏幕上了
      await restoreWoken(ruleId);
      return { ok: false, err: '页面锚定失败：无法把「' + (target.title || target.app_name) + '」切到前台（为安全起见未发送任何按键）' };
    }
    await sleep(700); // 等窗口真正可见可交互（标签栏渲染）

    // ── 第 4 步：【优先】切换到已打开的目标标签（多个候选逐个尝试并验证）──
    const switched = await switchToTargetTab(target.id, titleKw, urlAnchor, anchorSite);
    if (switched) {
      addLog(ruleId, { time: Date.now(), seq, step: 'ensure-page', desc: '页面锚定：已切换到目标标签', ok: true, output: '标签「' + (switched === true ? titleKw : switched) + '」' });
      if (wasMinimized) { await sleep(800); await runCmd(AD, ['minimize', '--window-id', target.id], 6000); }
      return { ok: true, action: 'tab-switched', title: titleKw, winId: target.id, wasMinimized };
    }

    // ── 第 5 步：没有可切换的目标标签 → 在当前标签地址栏导航 ──
    addLog(ruleId, { time: Date.now(), seq, step: 'ensure-page', desc: '页面锚定：当前标签直接导航到目标网址', ok: true, output: fullUrl });
    const navOk = await navigateInCurrentTab(target.id, fullUrl, titleKw, urlAnchor, anchorSite);
    if (navOk) {
      // 导航完成：恢复静默——原来是最小化的就最小化回去
      if (wasMinimized) { await sleep(1000); await runCmd(AD, ['minimize', '--window-id', target.id], 6000); }
      return { ok: true, action: 'navigated', title: fullUrl, winId: target.id, wasMinimized };
    }

    // ── 第 5 步：兜底——当前标签也导航不了（如被锁定/特殊页面）→ 新开标签 ──
    addLog(ruleId, { time: Date.now(), seq, step: 'ensure-page', desc: '页面锚定：当前标签无法导航，新开标签页', ok: true, output: fullUrl });
    if (!await pressInWindow(target.id, 'ctrl+t')) {
      if (wasMinimized) await runCmd(AD, ['minimize', '--window-id', target.id], 6000);
      return { ok: false, err: '页面锚定失败：目标窗口不在前台，已安全中止（未发送按键）' };
    }
    await sleep(1500); // 等新标签页就绪（各浏览器新标签页地址栏自动聚焦）
    await runCmd(AD, ['clipboard-set', fullUrl], 5000);
    if (!await pressInWindow(target.id, 'ctrl+v')) {
      if (wasMinimized) await runCmd(AD, ['minimize', '--window-id', target.id], 6000);
      return { ok: false, err: '页面锚定失败：粘贴前目标窗口失去前台，已安全中止' };
    }
    await sleep(500);
    if (!await pressInWindow(target.id, 'return')) {
      if (wasMinimized) await runCmd(AD, ['minimize', '--window-id', target.id], 6000);
      return { ok: false, err: '页面锚定失败：回车前目标窗口失去前台，已安全中止' };
    }
    // 等待加载并验证：标题或 URL 命中即成功
    for (let i = 0; i < 5; i++) {
      await sleep(2000);
      const lr3 = await runCmd(AD, ['list-windows'], 8000);
      const lj3 = parseJson(lr3.stdout);
      const w3 = ((lj3 && lj3.data) || []).find(w => w.id === target.id);
      const t3 = String((w3 && w3.title) || '');
      const u3 = await readAddressBar(target.id);
      if ((titleKw && t3.indexOf(titleKw) >= 0) || (u3 && urlPathEq(u3, urlAnchor))) {
        if (wasMinimized) await runCmd(AD, ['minimize', '--window-id', target.id], 6000); // 恢复静默
        return { ok: true, action: 'new-tab', title: fullUrl, winId: target.id, wasMinimized };
      }
    }
    const u4 = await readAddressBar(target.id);
    if (wasMinimized) await runCmd(AD, ['minimize', '--window-id', target.id], 6000); // 恢复静默
    if (u4) return { ok: false, err: '页面锚定失败：打开后停在 ' + u4 + '，与目标 ' + urlAnchor + ' 不符（可能需要登录/证书）' };
    return { ok: true, action: 'new-tab-unverified', title: fullUrl, winId: target.id, wasMinimized };
  } catch (e) {
    // 异常路径同样要还原（可能已经 restore 过窗口）
    await restoreWoken(ruleId);
    return { ok: false, err: '页面锚定检查失败：' + e.message };
  }
}

async function locateRef(loc, budgetMs, expectWinId) {
  const flag = LOCATOR_FLAG[loc.by] || '--name';
  const appKey = windowKeyword(loc.app);
  let lastErr = '';
  // 在预算时间内持续轮询（默认 3 次×1.2s；SPA 等慢页面可通过步骤 timeout 加大预算）：
  // 给「点完上一个元素后页面跳转/渲染」留足时间
  const deadline = Date.now() + Math.max(4000, Number(budgetMs) || 4000);
  let attempt = 0;
  while (true) {
    attempt++;
    // 窗口选择优先级：显式指定的应用 > 任务已锚定的窗口(expectWinId) > 当前前台窗口。
    // 锚定窗口优先于前台窗口：任务执行中用户切去干别的，步骤也不会点到别的程序里。
    let win = appKey ? await findWindowByKeyword(appKey) : null;
    if (!appKey) {
      win = await getFocusedWindow();
      if (expectWinId && (!win || win.id !== expectWinId)) {
        const lw = parseJson((await runCmd(AD, ['list-windows'], 8000)).stdout);
        const anchorWin = ((lw && lw.data) || []).find(w => w.id === expectWinId);
        if (anchorWin) win = anchorWin; // 锚定窗口还在 → 用它（find 按 window-id 不需要前台）
      }
    }
    const args = win
      ? ['find', '--window-id', win.id, flag, loc.query, '--timeout-ms', '8000']
      : ['find', '--app', appKey || loc.app, flag, loc.query, '--timeout-ms', '8000'];
    const r = await runCmd(AD, args, 15000);
    const timeUp = Date.now() >= deadline;
    if (r.ok) {
      // 页面加载中时 find 常常只返回浏览器工具栏按钮（menubutton），此时点它会把界面带跑偏：
      // 未超时前排除 menubutton 继续轮询等页面渲染；只有最后一轮才允许兜底点击。
      const m = pickMatch(r.stdout, loc.query, timeUp);
      if (m) return { ref: m.ref, matched: m, err: null, winId: win ? win.id : null };
      lastErr = '页面上没有相关元素';
    } else {
      lastErr = (r.stderr || r.stdout || ('exit ' + r.code) || '').slice(0, 200);
    }
    if (timeUp) break;
    await sleep(1500);
  }
  return { ref: null, err: '未找到匹配元素（在「' + (appKey || '当前窗口') + '」里按 ' + loc.by + ' 找「' + loc.query + '」重试 ' + attempt + ' 次共 ' + Math.round((Date.now() - (deadline - Math.max(4000, Number(budgetMs) || 4000))) / 1000) + ' 秒都没找到，' + lastErr + '）' };
}

async function execStep(step, ruleId, seq) {
  const s = step.command;
  if (s === 'wechat-send') return execWechatSend(step, ruleId, seq);
  const a = { ...(step.args || {}) };
  for (const key of ['text', 'value', 'fileUrl', 'imageUrl']) {
    if (typeof a[key] === 'string' && a[key].includes('{{')) a[key] = await renderText(a[key]);
  }
  let args, desc;

  switch (s) {
    case 'launch': {
      const app = a.app;
      const isUri = /^[a-z][a-z0-9+.-]*:/i.test(app) && !/^[a-z]:[\\/]/i.test(app);
      // .lnk 快捷方式：先解析目标程序，若已在运行则复用，绝不重复打开
      if (typeof app === 'string' && app.toLowerCase().endsWith('.lnk')) {
        const kw = windowKeyword(app); // 内部会解析 .lnk 目标
        const win = await findWindowByKeyword(kw);
        if (win) {
          // 通用防线：任务含物理按键步骤（press/wechat-send 等）时强制前台，
          // 即使 activate 未开启也不允许静默——按键发错窗口的代价远大于弹一下窗口
          if (!a.activate && !needsForeground.has(ruleId)) {
            // 静默模式：不弹窗口不抢焦点。
            // 仅适用于后续步骤为语义操作（find/click via ref，最小化也能执行）的任务。
            addLog(ruleId, { time: Date.now(), seq, step: s, desc: '应用已在运行', ok: true, output: '静默模式：不弹窗口，直接后台操作「' + (win.title || kw) + '」' });
            return { ok: true, output: '已在运行（静默）', cmd: 'noop-focus' };
          }
          // 需要前台：把窗口切到最前（物理按键类任务的硬性前提）
          args = ['focus-window', '--window-id', win.id];
          desc = '激活已打开的 ' + kw;
          break;
        }
        const target = resolveLnkTarget(app);
        if (target) {
          args = ['launch', target];
          if (a.activate) args.push('--activate');
          desc = '启动 ' + kw + '（' + target + '）';
          break;
        }
        // 解析不到目标：退回系统 start
        const r0 = await runCmd('cmd', ['/c', 'start', '', app], Number(step.timeout) || 15000);
        const o0 = r0.ok ? '已打开 ' + app : (r0.stderr || r0.stdout || '启动失败');
        addLog(ruleId, { time: Date.now(), seq, step: s, desc: '打开 ' + app, ok: r0.ok, output: o0 });
        return { ok: r0.ok, output: o0, cmd: 'start "' + app + '"' };
      }
      // 系统 URI（如 ms-settings:、https://）
      if (isUri) {
        const r1 = await runCmd('cmd', ['/c', 'start', '', app], Number(step.timeout) || 15000);
        const o1 = r1.ok ? '已打开 ' + app : (r1.stderr || r1.stdout || '启动失败');
        addLog(ruleId, { time: Date.now(), seq, step: s, desc: '打开 ' + app, ok: r1.ok, output: o1 });
        return { ok: r1.ok, output: o1, cmd: 'start "' + app + '"' };
      }
      const resolved = resolveAppPath(app);
      // 从完整路径里提取可识别的应用名（C:\...\molan126.exe -> molan126）
      const appKey = windowKeyword(app).toLowerCase();
      // 先检查应用是否已在运行，已运行则聚焦窗口而非重复启动
      let runningName = null;
      try {
        const lr = await runCmd(AD, ['list-apps'], 8000);
        const lj = parseJson(lr.stdout);
        if (lj && lj.data && lj.data.apps) {
          const found = lj.data.apps.find(x => (x.name || '').toLowerCase().replace(/\.exe$/i, '') === appKey);
          if (found) runningName = found.name;
        }
      } catch (e) {}
      if (runningName) {
        // 已在运行：不重复打开。
        // 通用防线：任务含物理按键步骤（press/wechat-send 等）时强制前台（needsForeground），
        // 只有纯语义点击任务且 activate 未开启时才静默（不弹窗不抢焦点）。
        const win = await findWindowByKeyword(appKey);
        if (win && !a.activate && !needsForeground.has(ruleId)) {
          addLog(ruleId, { time: Date.now(), seq, step: s, desc: '应用已在运行', ok: true, output: '静默模式：不弹窗口，直接后台操作「' + (win.title || windowKeyword(app)) + '」' });
          return { ok: true, output: '已在运行（静默）', cmd: 'noop-focus' };
        }
        if (win) args = ['focus-window', '--window-id', win.id];
        else args = ['focus-window', '--app', runningName];
        desc = '激活已打开的 ' + windowKeyword(app);
      } else {
        args = ['launch', resolved];
        if (a.activate) args.push('--activate');
        desc = '启动 ' + app;
      }
      break;
    }
    case 'close-app':
      args = ['close-app', windowKeyword(a.app)]; if (a.force) args.push('--force'); desc = '关闭 ' + a.app; break;
    case 'focus-window': {
      const win = await findWindowByKeyword(windowKeyword(a.app));
      if (win) { args = ['focus-window', '--window-id', win.id]; desc = '聚焦 ' + (win.title || a.app); }
      else { args = ['focus-window', '--app', windowKeyword(a.app)]; desc = '聚焦 ' + a.app; }
      break;
    }
    case 'list-windows': args = ['list-windows']; desc = '列出窗口'; break;
    case 'minimize': {
      const win = await findWindowByKeyword(windowKeyword(a.app));
      if (win) { args = ['minimize', '--window-id', win.id]; desc = '最小化 ' + (win.title || a.app); }
      else { args = ['minimize', '--app', windowKeyword(a.app)]; desc = '最小化 ' + a.app; }
      break;
    }
    case 'maximize': {
      const win = await findWindowByKeyword(windowKeyword(a.app));
      if (win) { args = ['maximize', '--window-id', win.id]; desc = '最大化 ' + (win.title || a.app); }
      else { args = ['maximize', '--app', windowKeyword(a.app)]; desc = '最大化 ' + a.app; }
      break;
    }
    case 'snapshot':
      args = ['snapshot', '--app', a.app]; if (a.compact) args.push('--compact'); if (a.skeleton) args.push('--skeleton'); desc = '快照 ' + a.app; break;
    case 'find':
      args = ['find', '--app', a.app, LOCATOR_FLAG[a.by || 'name'] || '--name', a.query]; desc = '查找 ' + a.query; break;
    case 'screenshot': {
      const app = a.app;
      let shotPath = (a.path || '').trim();
      if (!shotPath) {
        // 空路径：自动存到桌面，文件名带应用名 + 时间戳
        const desktop = path.join(process.env.USERPROFILE || process.env.HOME || '.', 'Desktop');
        const d = new Date();
        const p2 = (n) => String(n).padStart(2, '0');
        const ts = d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate()) + '-' + p2(d.getHours()) + p2(d.getMinutes()) + p2(d.getSeconds());
        const base = String(app).replace(/\.exe$/i, '').replace(/[\\/:*?"<>|]/g, '_') || 'screen';
        shotPath = path.join(desktop, 'screenshot-' + base + '-' + ts + '.png');
      } else if (!/\.png$/i.test(shotPath)) {
        shotPath = shotPath.replace(/[\\/]$/, '') + '.png';
      }
      args = ['screenshot', '--app', app, shotPath];
      desc = '截图 ' + app + ' → ' + shotPath;
      break;
    }
    case 'press':
      args = ['press', '--headed', a.keys]; desc = '按键 ' + a.keys; break;
    case 'clipboard-set':
      if (a.mode === 'file' && a.fileUrl) { args = ['clipboard-set', '--file-url', a.fileUrl]; desc = '复制文件 ' + a.fileUrl; }
      else if (a.mode === 'image' && a.imageUrl) { args = ['clipboard-set', '--image', a.imageUrl]; desc = '复制图片 ' + a.imageUrl; }
      else { args = ['clipboard-set', a.text || '']; desc = '写剪贴板'; }
      break;
    case 'clipboard-get': args = ['clipboard-get']; desc = '读剪贴板'; break;
    case 'wait': args = ['wait', String(a.ms || 1000)]; desc = '等待 ' + (a.ms || 1000) + 'ms'; break;
    case 'list-notifications': args = ['list-notifications']; desc = '列出通知'; break;
    case 'dismiss-notification':
      args = a.all ? ['dismiss-all-notifications'] : ['dismiss-notification']; desc = '关闭通知'; break;
    case 'get':
    case 'click':
    case 'double-click':
    case 'right-click':
    case 'set-value':
    case 'type':
    case 'clear':
    case 'select':
    case 'scroll':
    case 'hover': {
      const loc = step.locator || {};
      // 页面锚定：配置了 pageUrl 时，先确认/回到目标页面再操作
      if (loc.pageUrl) {
        const ep = await ensurePage(loc, ruleId, seq);
        if (!ep.ok) {
          addLog(ruleId, { time: Date.now(), seq, step: s, desc: stepDesc(step), ok: false, output: ep.err });
          return { ok: false, output: ep.err };
        }
        // 记住锚定的浏览器窗口：本任务后续未指定软件的步骤都锁定在它里面找元素，
        // 即使用户中途切换前台窗口也不会点错地方
        if (ep.winId) anchoredWin[ruleId] = ep.winId;
        if (ep.action !== 'same-tab' && ep.action !== 'title-match') await sleep(1500);
      }
      // 元素等待预算：至少 15 秒（慢页面/SPA 渲染需要时间），用户配了更大的 timeout 则用更大的
      const r = await locateRef(loc, Math.max(Number(step.timeout) || 0, 15000), anchoredWin[ruleId]);
      if (r.err) {
        addLog(ruleId, { time: Date.now(), seq, step: s, desc: stepDesc(step), ok: false, output: r.err });
        return { ok: false, output: r.err };
      }
      const ref = r.ref;
      // 记录“本次任务操作过的窗口”（wasMinimized=false 只作登记，不会主动收起来）：
      // 这样即使任务没配页面锚点，「执行完成后最小化窗口」也知道该收哪个窗口
      if (r.winId) noteWoken(ruleId, r.winId, false);
      // 日志显示“点了哪个元素”（名称+角色），而不是只显示 ref，方便核对点击顺序是否正确
      const matched = r.matched || {};
      const label = (matched.name ? '「' + matched.name + '」' : '') + (matched.role ? '(' + matched.role + ')' : '') + ' ' + ref;
      if (s === 'get') { args = ['get', ref]; if (a.property) args.push('--property', a.property); desc = '读取 ' + label; }
      else if (s === 'click') { args = ['click', ref]; desc = '点击 ' + label; }
      else if (s === 'double-click') { args = ['double-click', ref]; desc = '双击 ' + label; }
      else if (s === 'right-click') { args = ['right-click', ref]; desc = '右键 ' + label; }
      else if (s === 'set-value') { args = ['set-value', ref, a.value || '']; desc = '设置值 ' + label; }
      else if (s === 'type') { args = ['type', ref, a.text || '']; desc = '输入 ' + label; }
      else if (s === 'clear') { args = ['clear', ref]; desc = '清空 ' + label; }
      else if (s === 'select') { args = ['select', ref, a.value || '']; desc = '选择 ' + label; }
      else if (s === 'scroll') { args = ['scroll', ref]; if (a.direction) args.push('--direction', a.direction); desc = '滚动 ' + label; }
      else { args = ['hover', ref]; desc = '悬停 ' + label; }
      break;
    }
    default:
      addLog(ruleId, { time: Date.now(), seq, step: s, desc: stepDesc(step), ok: false, output: '未知命令 ' + s });
      return { ok: false, output: '未知命令 ' + s };
  }

  const timeout = Number(step.timeout) || 30000;
  let r = await runCmd(AD, args, timeout);
  // focus-window 偶发「did not become foreground」（前台被其它窗口抢占）：自动重试并升级为物理聚焦
  if (!r.ok && args[0] === 'focus-window') {
    for (let i = 0; i < 3 && !r.ok; i++) {
      await sleep(800);
      const retryArgs = args.indexOf('--headed') >= 0 ? args : args.concat(['--headed']);
      // 先尝试 restore（窗口可能被最小化）
      const widIdx = retryArgs.indexOf('--window-id');
      if (widIdx >= 0) await runCmd(AD, ['restore', '--window-id', retryArgs[widIdx + 1]], 6000);
      r = await runCmd(AD, retryArgs, timeout);
    }
  }
  const output = r.ok ? (r.stdout ? shortJson(r.stdout) : '完成') : (r.stderr || r.stdout || 'exit ' + r.code);
  addLog(ruleId, { time: Date.now(), seq, step: s, desc, ok: r.ok, output });
  // 静默任务把已关闭的应用重新拉起来后，任务结束要把它缩回去
  // （否则用户白天关掉的浏览器会被每 2 分钟的保活任务一直晾在屏幕上）
  if (r.ok && s === 'launch' && !a.activate && !needsForeground.has(ruleId)) {
    try {
      const kw = windowKeyword(a.app || '');
      const w = kw ? await findWindowByKeyword(kw) : null;
      if (w) noteWoken(ruleId, w.id, true);
    } catch (e) {}
  }
  return { ok: r.ok, output, cmd: args.join(' ') };
}

function stepDesc(step) {
  const labels = { launch: '启动应用', 'close-app': '关闭应用', click: '单击', 'set-value': '设置值', type: '输入', press: '按键', 'clipboard-set': '写剪贴板', wait: '等待', 'wechat-send': '微信发送' };
  return labels[step.command] || step.command;
}

async function execWechatSend(step, ruleId, seq) {
  const a = { ...(step.args || {}) };
  // 注意：消息正文不在这里渲染。因为 {{name}}（对方称谓）和 {{count}}（第几次）是逐个联系人变化的，
  // 必须放到下面的联系人循环里，按当前对象渲染，否则多人发送时会全部变成第一个人的名字。
  for (const key of ['contacts', 'contact']) {
    if (typeof a[key] === 'string' && a[key].includes('{{')) a[key] = await renderText(a[key]);
  }
  // 解析联系人列表：支持 contacts 数组（新）或 contact 字符串（旧，兼容逗号/换行分隔）
  let contacts = [];
  if (Array.isArray(a.contacts)) {
    contacts = a.contacts.map(x => String(x).trim()).filter(Boolean);
  } else if (typeof a.contact === 'string' && a.contact.trim()) {
    contacts = a.contact.split(/[,，、\n]/).map(x => x.trim()).filter(Boolean);
  }
  if (!contacts.length) {
    addLog(ruleId, { time: Date.now(), seq, step: 'wechat-send', desc: '微信发送', ok: false, output: '聊天对象为空' });
    return { ok: false, output: '聊天对象为空' };
  }
  const mode = a.mode || 'text';

  // 遍历联系人，逐个发送
  addLog(ruleId, { time: Date.now(), seq, step: 'wechat-send', desc: '微信发送（共 ' + contacts.length + ' 个对象）', ok: true, output: '对象：' + contacts.join('、') });
  for (let c = 0; c < contacts.length; c++) {
    const contact = contacts[c];
    currentSendIndex = c + 1; // 第几次发送（供 {{count}} 变量渲染）
    currentContactName = contact; // 当前对象（供 {{name}} 称谓变量渲染）
    // 正文按当前联系人渲染一次，{{name}}/{{count}} 才会各自不同
    const bodyText = await renderText(String(mode === 'image' ? (a.imageUrl || '') : mode === 'file' ? (a.fileUrl || '') : (a.text || '')));
    const content = mode === 'image' ? { command: 'clipboard-set', args: { mode: 'image', imageUrl: bodyText }, locator: null, timeout: 5000, retry: 0 }
      : mode === 'file' ? { command: 'clipboard-set', args: { mode: 'file', fileUrl: bodyText }, locator: null, timeout: 5000, retry: 0 }
      : { command: 'clipboard-set', args: { mode: 'text', text: bodyText }, locator: null, timeout: 5000, retry: 0 };
    if (stopFlags.has(ruleId)) {
      addLog(ruleId, { time: Date.now(), seq, step: 'wechat-send', desc: '微信发送给 ' + contact, ok: true, output: '已手动停止' });
      return { ok: true, stopped: true };
    }
    const subs = [
      { command: 'launch', args: { app: 'weixin', activate: true }, locator: null, timeout: 30000, retry: 1 },
      { command: 'press', args: { keys: 'ctrl+f' }, locator: null, timeout: 5000, retry: 1 },
      { command: 'clipboard-set', args: { mode: 'text', text: contact }, locator: null, timeout: 5000, retry: 0 },
      { command: 'press', args: { keys: 'ctrl+v' }, locator: null, timeout: 5000, retry: 1 },
      { command: 'press', args: { keys: 'enter' }, locator: null, timeout: 5000, retry: 1 },
      { command: 'wait', args: { ms: 600 }, locator: null, timeout: 5000, retry: 0 },
      content,
      { command: 'press', args: { keys: 'ctrl+v' }, locator: null, timeout: 5000, retry: 1 },
      { command: 'press', args: { keys: 'enter' }, locator: null, timeout: 5000, retry: 1 }
    ];
    addLog(ruleId, { time: Date.now(), seq, step: 'wechat-send', desc: '微信发送给 ' + contact + '（第 ' + (c + 1) + '/' + contacts.length + ' 个）', ok: true, output: '开始发送' });
    let ok = true, lastOut = '';
    for (let si = 0; si < subs.length; si++) {
      const sub = subs[si];
      if (stopFlags.has(ruleId)) {
        addLog(ruleId, { time: Date.now(), seq, step: 'wechat-send', desc: '微信发送给 ' + contact, ok: true, output: '已手动停止' });
        return { ok: true, stopped: true };
      }
      const r = await execStep(sub, ruleId, seq);
      if (!r.ok) { ok = false; lastOut = r.output; break; }
      lastOut = r.output;
      // 安全防线：launch/聚焦微信之后，验证前台确实是微信窗口才继续发物理按键。
      // 否则按键会打进用户正在用的其它程序（此前静默 bug 就是这样把 ctrl+f/回车发进了浏览器）。
      if (sub.command === 'launch') {
        const fw = await getFocusedWindow();
        const fwName = String((fw && fw.app_name) || '').toLowerCase();
        if (fwName.indexOf('weixin') < 0 && fwName.indexOf('wechat') < 0) {
          // 再试一次强力聚焦
          const wxWin = await findWindowByKeyword('weixin');
          if (wxWin) await runCmd(AD, ['focus-window', '--window-id', wxWin.id, '--headed'], 8000);
          await sleep(600);
          const fw2 = await getFocusedWindow();
          const fw2Name = String((fw2 && fw2.app_name) || '').toLowerCase();
          if (fw2Name.indexOf('weixin') < 0 && fw2Name.indexOf('wechat') < 0) {
            ok = false;
            lastOut = '微信窗口无法切到前台（当前前台是 ' + ((fw2 && fw2.app_name) || '未知') + '），为安全起见未发送任何按键';
            break;
          }
        }
      }
    }
    if (!ok) {
      addLog(ruleId, { time: Date.now(), seq, step: 'wechat-send', desc: '微信发送给 ' + contact, ok: false, output: lastOut });
      return { ok: false, output: lastOut };
    }
    addLog(ruleId, { time: Date.now(), seq, step: 'wechat-send', desc: '微信发送给 ' + contact, ok: true, output: '发送完成' });
  }
  currentContactName = '';
  // 发送完成：最小化微信窗口，静默发送不打扰用户当前操作
  try {
    const mr = await runCmd(AD, ['minimize', '--app', 'Weixin.exe'], 6000);
    addLog(ruleId, { time: Date.now(), seq, step: 'wechat-send', desc: '静默处理：最小化微信窗口', ok: mr.ok, output: mr.ok ? '已最小化，不影响你继续操作' : (mr.stderr || mr.stdout || '最小化失败（可忽略）') });
  } catch (e) {}
  return { ok: true, output: '已发送给 ' + contacts.length + ' 个对象：' + contacts.join('、') };
}

function shortJson(s) {
  try { return JSON.stringify(JSON.parse(s)); } catch (e) { return s; }
}

/* ============ 规则执行 ============ */
const running = new Set();
const stopFlags = new Set();
const anchoredWin = {}; // ruleId -> 已锚定的浏览器窗口 id（任务内后续步骤锁定在该窗口操作）

/* 本次任务「临时唤醒过」的窗口登记表：ruleId -> Map(winId -> 原本是否最小化)。
   用途：静默任务中途为了切标签/导航/启动应用不得不把窗口弄到前台，
   无论后面成功还是出错，任务结束时都要还原成用户原来的状态（该最小化的缩回去），
   避免「网页操作完了窗口还晾在屏幕上」。 */
const wokenWin = {};
function noteWoken(ruleId, winId, wasMinimized) {
  if (!ruleId || !winId) return;
  if (!wokenWin[ruleId]) wokenWin[ruleId] = new Map();
  if (!wokenWin[ruleId].has(winId)) wokenWin[ruleId].set(winId, wasMinimized !== false);
}
async function restoreWoken(ruleId, force) {
  const m = wokenWin[ruleId];
  if (!m || !m.size) return;
  for (const [winId, wasMin] of m) {
    // force=true：任务里勾了「执行完成后最小化窗口」，不管原来是什么状态都收起来
    if (!force && !wasMin) continue;
    try {
      // 只有“现在确实不在最小化”时才动手：既避免无意义操作，也让日志只在真需要时出现
      const lr = await runCmd(AD, ['list-windows'], 8000);
      const lj = parseJson(lr.stdout);
      const w = ((lj && lj.data) || []).find(x => x.id === winId);
      if (!w || w.minimized) continue;
      const r = await runCmd(AD, ['minimize', '--window-id', winId], 6000);
      addLog(ruleId, { time: Date.now(), seq: 0, step: 'restore-window', desc: '收尾：窗口已缩回最小化', ok: r.ok, output: String(w.title || winId) });
    } catch (e) {}
  }
  delete wokenWin[ruleId];
}

/* 通用规则：任务里只要包含“物理按键”类步骤（press/wechat-send 等），
   该任务就【需要前台窗口】——launch 步骤不允许静默跳过聚焦。
   物理按键由操作系统发给前台窗口，这是系统机制，任何软件都无法后台收发。
   纯语义步骤（find/click/set-value/type via ref 等）才支持最小化静默执行。 */
function ruleNeedsForeground(rule) {
  const steps = (rule && rule.steps) || [];
  return steps.some(s => {
    const c = s.command;
    if (c === 'wechat-send') return true;               // 微信复合命令=物理按键序列
    if (c === 'press' || c === 'double-click' || c === 'triple-click' || c === 'right-click'
        || c === 'hover' || c === 'drag' || c === 'mouse-click' || c === 'mouse-wheel') return true; // 物理输入类
    return false;
  });
}
// 执行期标记：当前规则需要前台（runRule 开始时计算，launch 分支读取）
const needsForeground = new Set();

/* ============ 全局执行队列（避免多任务并发冲突） ============
   所有任务都在同一块屏幕、同一个键盘鼠标和窗口焦点上操作，
   同时执行必然互相干扰（A 刚切到窗口，B 又把焦点抢走）。
   因此：无论手动还是定时触发，一律进入全局串行队列，
   同一时刻只执行一个任务，其余排队等待，并在日志里明确提示。 */
let execQueue = Promise.resolve();
const queued = new Set(); // 已排队（尚未开始）的规则 id，防重复入队

function enqueueRun(rule, trigger) {
  if (running.has(rule.id)) return;   // 同一任务正在执行，忽略重复触发
  if (queued.has(rule.id)) return;    // 同一任务已在排队，忽略重复触发
  queued.add(rule.id);
  if (running.size > 0) {
    const busy = [...running].map(id => (rules.find(x => x.id === id) || {}).name || id).join('、');
    addLog(rule.id, { time: Date.now(), seq: 0, step: 'queue', desc: '排队等待', ok: true, output: '正在执行的任务：' + busy + '；完成后自动开始本任务（' + trigger + ' 触发）' });
  }
  execQueue = execQueue.then(async () => {
    queued.delete(rule.id);
    // 排队期间被用户暂停/停止过 → 直接取消本次执行，不再抢屏幕
    if (stopFlags.has(rule.id)) {
      stopFlags.delete(rule.id);
      addLog(rule.id, { time: Date.now(), seq: 0, step: 'end', desc: '已取消（排队期间被暂停/停止）', ok: true, output: '任务未执行' });
      return;
    }
    try { await runRule(rule, trigger); } catch (e) { /* runRule 内部已兜底 */ }
  });
}

async function runRule(rule, trigger) {
  if (running.has(rule.id)) return { ok: false, output: '规则正在执行中' };
  running.add(rule.id);
  stopFlags.delete(rule.id);
  // 「重复 N 次后结束」只统计真正开始执行的定时轮次（手动执行不占用这个次数）
  if (trigger === 'schedule') execCount[rule.id] = (execCount[rule.id] || 0) + 1;
  delete anchoredWin[rule.id]; // 每轮执行重新锚定窗口（上一轮的窗口可能已被用户关掉）
  // 通用防线：含物理按键步骤的任务标记为“需要前台”，launch 不允许静默跳过聚焦
  if (ruleNeedsForeground(rule)) needsForeground.add(rule.id);
  else needsForeground.delete(rule.id);
  addLog(rule.id, { time: Date.now(), seq: 0, step: 'start', desc: '开始执行（' + trigger + '）', ok: true, output: rule.name });
  const results = [];
  try {
    for (let i = 0; i < rule.steps.length; i++) {
      if (stopFlags.has(rule.id)) {
        addLog(rule.id, { time: Date.now(), seq: 0, step: 'end', desc: '已手动停止', ok: true, output: '用户停止了执行' });
        return { ok: true, stopped: true, results };
      }
      const r = await execStep(rule.steps[i], rule.id, i + 1);
      results.push(r);
      if (!r.ok) break;
    }
    const ok = results.every(r => r.ok);
    addLog(rule.id, { time: Date.now(), seq: 0, step: 'end', desc: ok ? '执行完成' : '执行中断', ok, output: ok ? '全部步骤完成' : '在第 ' + results.length + ' 步中断' });
    return { ok, results };
  } finally {
    // 收尾：把本次任务临时唤醒过的窗口还原回最小化（成功、中断、异常都走这里）；
    // 若任务勾了「执行完成后最小化窗口」，则连原本开着的窗口也一起收起来。
    const forceMin = !!(rule.schedule && rule.schedule.minimizeAfterRun);
    if (forceMin) {
      const m = wokenWin[rule.id];
      if (!m || !m.size) {
        // 任务没配页面锚点、也没成功定位到元素时，按步骤里出现过的应用名找窗口
        try {
          const hint = (rule.steps.find(s => s.command === 'launch' && s.args && s.args.app) || {}).args
            || (rule.steps.find(s => s.locator && s.locator.app) || {}).locator;
          const kw = windowKeyword((hint && hint.app) || '');
          const w = kw ? await findWindowByKeyword(kw) : null;
          if (w) noteWoken(rule.id, w.id, true);
        } catch (e) {}
      }
    }
    try { await restoreWoken(rule.id, forceMin); } catch (e) {}
    running.delete(rule.id);
    stopFlags.delete(rule.id);
    delete anchoredWin[rule.id];
    needsForeground.delete(rule.id);
  }
}

/* ============ 调度器 ============ */
// 判断日期 d 是否为当月第 nth 个 weekday（0=周日）
function nthWeekdayMatch(d, nth, weekday) {
  let count = 0;
  for (let day = 1; day <= d.getDate(); day++) {
    if (new Date(d.getFullYear(), d.getMonth(), day).getDay() === weekday) count++;
  }
  return d.getDay() === weekday && count === nth;
}

// 「每天 + 随机时间」的当日随机时刻表：
// 种子 = 任务 id + 日期 → 同一天内结果固定（重启、多次 tick 都不会变），跨天自动重新随机。
// 把 08:00–22:00 均分成 N 段，每段内随机取一分钟，避免几次挤在一起。
function dailyRandomMinutes(rule, d) {
  const s = rule.schedule || {};
  const n = Math.min(12, Math.max(1, Number(s.randomCount) || 1));
  const START = 8 * 60, END = 22 * 60; // 08:00 – 22:00
  const bucket = Math.floor((END - START) / n);
  const key = String(rule.id || 'rule') + '#' + d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
  let seed = 2166136261;
  for (let i = 0; i < key.length; i++) { seed ^= key.charCodeAt(i); seed = Math.imul(seed, 16777619) >>> 0; }
  const rnd = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; };
  const out = [];
  for (let i = 0; i < n; i++) out.push(START + i * bucket + Math.floor(rnd() * bucket));
  return out;
}

/* ---------- 周期起算日（schedule.startDate，YYYY-MM-DD） ----------
   以前「每 N 天/周/月」只看 lastRun（内存里上次实际执行时间）：首次到点就执行，
   重启 / 关机 / 暂停 / 跳过周末后相位会漂移甚至重置，也无法指定「从昨天算」。
   设置 startDate 后改为以该日为第 0 天做确定性推算；留空则完全保持原行为。 */
function parseStartDate(v) {
  const s = String(v == null ? '' : v).trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return null;
  const [y, m, d] = s.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  // 2026-02-30 这类非法日期会被 Date 自动进位，必须挡掉（否则规则永不执行）
  if (dt.getFullYear() !== y || dt.getMonth() !== m - 1 || dt.getDate() !== d) return null;
  return dt;
}
// 本地日历天序号：只按年月日算，不受夏令时 / 毫秒误差影响
function dayNumber(y, m, d) {
  return Math.round((new Date(y, m, d).getTime() - new Date(2000, 0, 1).getTime()) / 86400000);
}
// 固定锚点周期：今天是否落在第 k 个周期日（k = 0,1,2…，第 0 天即开始日）
function intervalFromStart(s, d, sd) {
  const n = Math.max(1, Number(s.customInterval) || 1);
  const diff = dayNumber(d.getFullYear(), d.getMonth(), d.getDate()) -
               dayNumber(sd.getFullYear(), sd.getMonth(), sd.getDate());
  if (diff < 0) return false;
  if (s.customUnit === 'day') return diff % n === 0;
  if (s.customUnit === 'week') return diff % (n * 7) === 0;
  if (s.customUnit === 'month') {
    const months = (d.getFullYear() - sd.getFullYear()) * 12 + (d.getMonth() - sd.getMonth());
    if (months < 0 || months % n !== 0) return false;
    const dim = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
    // 31 号遇小月落在月末；必须精确等于目标日，否则一个月会连着触发好几天
    return d.getDate() === Math.min(sd.getDate(), dim);
  }
  return false;
}

// 判断规则在时刻 d 是否应触发（时间点 + 频率匹配）
function scheduleMatch(rule, d) {
  const s = rule.schedule || {};
  if (s.frequency === 'none') return false;
  const sd = parseStartDate(s.startDate);
  // 开始日期之前一律不触发（当天 00:00 起生效）；留空 = 老规则一字不变
  if (sd && new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() < sd.getTime()) return false;

  // 【每天 + 随机时间】开了随机后，界面上的固定时刻不生效，改按当天随机时刻表执行
  if (s.frequency === 'daily' && s.randomEnabled) {
    if (s.skipWeekends && (d.getDay() === 0 || d.getDay() === 6)) return false;
    return dailyRandomMinutes(rule, d).indexOf(d.getHours() * 60 + d.getMinutes()) >= 0;
  }
  const [sh, sm] = (s.startTime || '09:00').split(':').map(Number);
  const isIntervalFreq = s.frequency === 'custom' && (s.customUnit === 'minute' || s.customUnit === 'hour');
  if (isIntervalFreq && (isNaN(sh) || isNaN(sm))) return false;

  // 【间隔型】自定义 + 分钟/小时：从「开始时间」起按固定间隔触发，不要求精确匹配某时某分
  // 例：开始 09:00、每隔 2 小时 → 09:00、11:00、13:00...（跨天连续，不因午夜中断）
  if (s.frequency === 'custom' && (s.customUnit === 'minute' || s.customUnit === 'hour')) {
    const unitMs = s.customUnit === 'minute' ? 60000 : 3600000;
    const intervalMs = Math.max(60000, (Number(s.customInterval) || 1) * unitMs);
    // 间隔 ≤ 24 小时：起点用「最近一次经过的开始时间」，每天都会重新对齐到开始时刻。
    // （否则像「每 5 小时」这种除不尽一天的间隔，相位会一天天偏移，越跑越对不上开始时间）
    // 间隔 > 24 小时：必须换成固定基准日，否则每天到点 elapsed 又变回 0 而命中，退化成“每天一次”
    let anchor;
    if (intervalMs <= 86400000) {
      anchor = new Date(d.getFullYear(), d.getMonth(), d.getDate(), sh, sm, 0, 0);
      if (d.getTime() < anchor.getTime()) anchor = new Date(d.getFullYear(), d.getMonth(), d.getDate() - 1, sh, sm, 0, 0);
    } else {
      // 长间隔：设了开始日期就用它当基准日（相位可自己定），否则沿用固定基准日（老规则不变）
      anchor = sd
        ? new Date(sd.getFullYear(), sd.getMonth(), sd.getDate(), sh, sm, 0, 0)
        : new Date(2020, 0, 1, sh, sm, 0, 0);
    }
    const elapsed = d.getTime() - anchor.getTime();
    if (elapsed < 0) return false;
    // 落在间隔整数倍的那一分钟内（tick 每秒跑，靠 tick 的分钟级去重保证只执行一次）
    return (elapsed % intervalMs) < 60000;
  }

  // 其余频率（每天/每周/每月/每年/每隔 N 天周月）：先精确匹配执行时刻
  // 支持一个模式配多个时间点：times = ['09:00','12:00','18:00']（每天/每周/每月/每年都适用）；
  // 没配 times 时退回单一 startTime，保证老数据照旧工作。
  const timeList = (Array.isArray(s.times) && s.times.length ? s.times : [s.startTime || '09:00'])
    .map(t => {
      const p = String(t).split(':');
      const hh = parseInt(p[0], 10), mm = parseInt(p[1], 10);
      return (isNaN(hh) || isNaN(mm)) ? null : String(hh).padStart(2, '0') + ':' + String(mm).padStart(2, '0');
    }).filter(Boolean);
  if (!timeList.length) return false;
  const curHM = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  if (timeList.indexOf(curHM) < 0) return false;

  // 「跳过周末」对所有按日/周/月/年重复的模式统一生效（原先只在“每天”里生效，
  // 但开关在界面上对所有频率都显示，属于不一致）；间隔型不受此开关影响。
  if (s.skipWeekends && (d.getDay() === 0 || d.getDay() === 6)) return false;

  switch (s.frequency) {
    case 'daily':
      return true;
    case 'weekly':
      return (s.weekdays || []).map(Number).indexOf(d.getDay()) >= 0;
    case 'monthly': {
      if (s.monthlyType === 'day') {
        const dim = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate(); // 当月实际天数
        // 选 31 号但该月只有 30 天时，落在当月最后一天（否则整月一次都不执行）
        return d.getDate() === Math.min(Number(s.monthlyDay) || 1, dim);
      }
      return nthWeekdayMatch(d, Number(s.monthlyNth) || 1, Number(s.monthlyWeekday) || 1);
    }
    case 'yearly': {
      // 每年：支持多选日期，yearlyDates = ['03-15','11-20']（月-日，每年循环）
      const list = Array.isArray(s.yearlyDates) ? s.yearlyDates : [];
      if (!list.length) return d.getMonth() === 0 && d.getDate() === 1; // 无配置时兜底为元旦
      const key = String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
      return list.map(String).indexOf(key) >= 0;
    }
    case 'custom': {
      // 设了开始日期：按固定锚点算「第几个周期日」，与上次执行时间、重启、关机都无关
      if (sd) return intervalFromStart(s, d, sd);
      // 未设开始日期：保持原来的「距上次实际执行 ≥ N 天/周/月」逻辑（老规则兼容）
      const lr = lastRun[rule.id];
      if (!lr || !lr.time) return true;
      const n = Math.max(1, Number(s.customInterval) || 1);
      if (s.customUnit === 'day') return (d.getTime() - lr.time) >= n * 86400000;
      if (s.customUnit === 'week') return (d.getTime() - lr.time) >= n * 604800000;
      // 月：按日历月算。原来用 30 天近似（2592000000ms），「每 1 个月」会慢慢变成每 30 天，
      // 跑久了日期越飘越早；改成比较年月差 + 日期（大月 31 号遇到 30 天的月份落在月末）
      const prev = new Date(lr.time);
      const months = (d.getFullYear() - prev.getFullYear()) * 12 + (d.getMonth() - prev.getMonth());
      if (months !== n) return months > n;
      const dim = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
      return d.getDate() >= Math.min(prev.getDate(), dim);
    }
    default:
      return false;
  }
}

// 判断重复是否已到结束条件
function endReached(rule) {
  const s = rule.schedule || {};
  if (s.endType === 'after') return (execCount[rule.id] || 0) >= (s.endCount || 0);
  if (s.endType === 'on-date' && s.endDate) {
    const today = new Date(); today.setHours(0, 0, 0, 0);
    return today > new Date(s.endDate + 'T00:00:00');
  }
  return false;
}

const lastRun = {}; // ruleId -> { key, time }
const execCount = {}; // ruleId -> number
let schedTimer = null;

function tick() {
  const now = new Date();
  rules.forEach(rule => {
    if (!rule.enabled) return;
    if (endReached(rule)) return;
    if (!scheduleMatch(rule, now)) return;
    const key = now.getFullYear() + '-' + now.getMonth() + '-' + now.getDate() + '-' + now.getHours() + ':' + now.getMinutes();
    const lr = lastRun[rule.id];
    if (lr && lr.key === key) return;
    lastRun[rule.id] = { key, time: now.getTime() };
    // 注意：execCount 不在这里加。这里只是“触发”，可能因为该任务正在执行而被队列去重吞掉，
    // 也可能排队期间被用户暂停取消；那样也算一次会让「重复 N 次后结束」提前结束。
    enqueueRun(rule, 'schedule');
  });
}

function startScheduler() {
  if (schedTimer) return;
  schedTimer = setInterval(tick, 1000);
  console.log('[scheduler] started');
}
function stopScheduler() {
  if (schedTimer) { clearInterval(schedTimer); schedTimer = null; console.log('[scheduler] stopped'); }
}

/* ============ 应用扫描（启动应用场景） ============ */
// 按应用名/路径智能匹配图标
function iconFor(name, p) {
  const s = String(name || '') + ' ' + String(p || '');
  const l = s.toLowerCase();
  if (/chrome|edge|firefox|browser|浏览器|opera|brave|360se|sogou/.test(l)) return '🌐';
  if (/wechat|weixin|微信|qq(?!music)|telegram|钉钉|dingtalk|feishu|飞书|slack|企业微信/.test(l)) return '💬';
  if (/notepad|记事本|vscode|code|sublime|编辑器|editplus|atom|typora/.test(l)) return '📝';
  if (/excel|表格|wps|spreadsheet|numbers/.test(l)) return '📊';
  if (/powerpoint|ppt|演示|slides|keynote/.test(l)) return '📽️';
  if (/word|文档|docx|writer|pages/.test(l)) return '📄';
  if (/music|音乐|网易云|spotify|qqmusic|千千|kugou|酷狗/.test(l)) return '🎵';
  if (/vlc|potplayer|video|视频|播放器|player|bilibili|哔哩/.test(l)) return '🎬';
  if (/photo|画图|paint|image|图片|看图|mspaint|photoshop|ps/.test(l)) return '🖼️';
  if (/cmd|powershell|terminal|终端|命令|bash|windows terminal/.test(l)) return '⌨️';
  if (/settings|设置|控制面板|control/.test(l)) return '⚙️';
  if (/explorer|资源管理器|文件管理|folder|我的电脑/.test(l)) return '📁';
  if (/steam|game|游戏|epic/.test(l)) return '🎮';
  if (/mail|outlook|邮件|foxmail|thunderbird/.test(l)) return '📧';
  if (/calc|计算器/.test(l)) return '🧮';
  if (/snipping|截图|snip|截图工具/.test(l)) return '📸';
  if (/regedit|注册表/.test(l)) return '🔧';
  if (/taskmgr|任务管理器/.test(l)) return '📊';
  if (/压缩|zip|rar|7z|bandizip|winrar/.test(l)) return '🗜️';
  if (/pdf|acrobat|阅读|reader/.test(l)) return '📕';
  if (/dictionary|词典|翻译|translate/.test(l)) return '📖';
  if (/clock|时钟|闹钟|calendar|日历/.test(l)) return '🕐';
  if (/store|商店|microsoft store/.test(l)) return '🛍️';
  return '📦';
}

// 常见系统应用（不依赖开始菜单快捷方式，直接给 exe 路径 + 中文/英文别名）
const BUILTIN_APPS = [
  { name: '记事本', path: 'C:\\Windows\\System32\\notepad.exe', keywords: 'notepad 记事本 文本' },
  { name: '计算器', path: 'C:\\Windows\\System32\\calc.exe', keywords: 'calc calculator 计算器' },
  { name: '画图', path: 'C:\\Windows\\System32\\mspaint.exe', keywords: 'mspaint paint 画图 绘图' },
  { name: '命令提示符', path: 'C:\\Windows\\System32\\cmd.exe', keywords: 'cmd 命令提示符 命令行 终端' },
  { name: 'PowerShell', path: 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe', keywords: 'powershell ps 终端' },
  { name: '任务管理器', path: 'C:\\Windows\\System32\\Taskmgr.exe', keywords: 'taskmgr 任务管理器' },
  { name: '控制面板', path: 'C:\\Windows\\System32\\control.exe', keywords: 'control 控制面板' },
  { name: '注册表编辑器', path: 'C:\\Windows\\regedit.exe', keywords: 'regedit 注册表' },
  { name: '资源管理器', path: 'C:\\Windows\\explorer.exe', keywords: 'explorer 资源管理器 文件' },
  { name: '写字板', path: 'C:\\Windows\\System32\\write.exe', keywords: 'write wordpad 写字板' },
  { name: '截图工具', path: 'C:\\Windows\\System32\\SnippingTool.exe', keywords: 'snipping 截图 截屏' },
  { name: '系统设置', path: 'ms-settings:', keywords: 'settings 设置 系统设置' }
];

function scanShortcuts() {
  const dirs = [
    path.join(process.env.APPDATA || '', 'Microsoft', 'Windows', 'Start Menu', 'Programs'),
    'C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs',
    path.join(process.env.USERPROFILE || '', 'Desktop'),
    'C:\\Users\\Public\\Desktop'
  ];
  const seen = new Set();
  const results = [];
  const addFile = (full) => {
    const name = path.basename(full).replace(/\.lnk$/i, '');
    if (!name || seen.has(name)) return;
    seen.add(name);
    results.push({ name, path: full, keywords: name, icon: iconFor(name, full) });
  };
  // 先放入常见系统应用
  for (const a of BUILTIN_APPS) {
    if (a.path.indexOf('ms-settings') === 0 || fs.existsSync(a.path)) {
      if (!seen.has(a.name)) { seen.add(a.name); results.push({ ...a, icon: iconFor(a.name, a.path) }); }
    }
  }
  const walk = (dir, depth) => {
    if (depth > 3) return;
    if (!fs.existsSync(dir)) return;
    try {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const e of entries) {
        const full = path.join(dir, e.name);
        if (e.isDirectory()) walk(full, depth + 1);
        else if (e.name.toLowerCase().endsWith('.lnk')) addFile(full);
      }
    } catch (e) {}
  };
  for (const d of dirs) walk(d, 0);
  return results;
}

/* ============ HTTP 服务 ============ */
function sendJson(res, obj, status = 200) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
  });
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve) => {
    let data = '';
    req.on('data', c => { data += c; if (data.length > 10 * 1024 * 1024) req.destroy(); });
    req.on('end', () => { try { resolve(data ? JSON.parse(data) : {}); } catch (e) { resolve({}); } });
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const p = url.pathname;

  if (req.method === 'OPTIONS') { sendJson(res, {}); return; }

  // API
  if (p === '/api/health') { sendJson(res, { ok: true, version: APP_VERSION, scheduler: !!schedTimer }); return; }
  if (p === '/api/queue-status' && req.method === 'GET') {
    // 当前执行中/排队中的任务（供前端展示，避免用户困惑“为什么没动”）
    sendJson(res, {
      ok: true,
      running: [...running].map(id => ({ id, name: (rules.find(x => x.id === id) || {}).name || id })),
      queued: [...queued].map(id => ({ id, name: (rules.find(x => x.id === id) || {}).name || id }))
    }); return;
  }

  if (p === '/api/scan-elements' && req.method === 'GET') {
    // 扫描某个窗口的可点击元素，返回文字列表（供前端点选，免去手抄）
    const appParam = url.searchParams.get('app') || '';
    const windowId = url.searchParams.get('windowId') || '';
    let args;
    if (windowId) {
      args = ['snapshot', '--window-id', windowId, '--compact'];
    } else {
      const appKey = windowKeyword(appParam);
      const win = await findWindowByKeyword(appKey);
      if (win) args = ['snapshot', '--window-id', win.id, '--compact'];
      else args = ['snapshot', '--app', appKey, '--compact'];
    }
    const r = await runCmd(AD, args, 25000);
    const j = parseJson(r.stdout);
    if (!j || !j.ok || !j.data || !j.data.tree) {
      sendJson(res, { ok: false, error: '扫描失败：没找到该窗口，请先打开它' }); return;
    }
    const items = [];
    const wantRoles = ['button', 'link', 'menuitem', 'tab', 'tabitem', 'text', 'statictext', 'listitem', 'treeitem', 'image', 'checkbox'];
    const walk = (node) => {
      if (!node) return;
      if (node.name && wantRoles.indexOf(node.role) >= 0) {
        const nm = String(node.name).trim();
        if (nm && nm.length <= 80) items.push({ name: nm, role: node.role, roleDesc: node.role_description || '' });
      }
      (node.children || []).forEach(walk);
    };
    walk(j.data.tree);
    const seen = new Set();
    const uniq = items.filter(x => {
      const k = x.name + '|' + x.role;
      if (seen.has(k)) return false;
      seen.add(k); return true;
    });
    sendJson(res, { ok: true, app: j.data.app || appParam, count: uniq.length, items: uniq.slice(0, 400) });
    return;
  }
  if (p === '/api/current-page' && req.method === 'GET') {
    // 读取浏览器窗口的网址（地址栏）和标题，供前端「📌 抓取当前页」一键填入页面锚点。
    // 注意：点击按钮时前台是助手自己，所以在全部窗口中查找带 http 地址栏的浏览器窗口。
    try {
      const appHint = (url.searchParams.get('app') || '').trim().toLowerCase();
      const lr = await runCmd(AD, ['list-windows'], 8000);
      const lj = parseJson(lr.stdout);
      let wins = ((lj && lj.data) || []);
      // 最小化窗口的地址栏同样可读（find 按 window-id 不依赖前台），
      // 只是排在后面：优先返回可见窗口，但最小化的也要能找到（否则任务在后台跑时抓不到页面）
      wins = wins.filter(w => !w.minimized).concat(wins.filter(w => w.minimized));
      if (appHint) {
        const preferred = wins.filter(w => String(w.app_name || '').toLowerCase().indexOf(appHint) >= 0 || String(w.title || '').toLowerCase().indexOf(appHint) >= 0);
        if (preferred.length) wins = preferred;
      }
      for (const win of wins) {
        const fr = await runCmd(AD, ['find', '--window-id', win.id, '--role', 'textfield', '--timeout-ms', '10000'], 20000);
        const fj = parseJson(fr.stdout);
        const fields = ((fj && fj.data && fj.data.matches) || []);
        const addr = fields.find(f => typeof f.value === 'string' && looksLikeUrl(f.value));
        if (addr) { sendJson(res, { ok: true, url: addr.value, title: win.title || '', window: win.id, app: win.app_name }); return; }
      }
      sendJson(res, { ok: false, error: '没找到打开着网页的浏览器窗口，请先打开目标网页再抓取' });
    } catch (e) { sendJson(res, { ok: false, error: e.message }); }
    return;
  }
  if (p === '/api/apps' && req.method === 'GET') {
    const apps = scanShortcuts();
    // 附带运行中的应用（agent-desktop list-apps）
    try {
      const lr = await runCmd(AD, ['list-apps'], 8000);
      const lj = parseJson(lr.stdout);
      const running = (lj && lj.data && (lj.data.apps || lj.data)) || [];
      const runningNames = running.map(x => (x.name || '').replace(/\.exe$/i, '')).filter(Boolean);
      const runningIcons = {};
      runningNames.forEach(n => { runningIcons[n] = iconFor(n, ''); });
      sendJson(res, { apps, running: runningNames, runningIcons }); return;
    } catch (e) { sendJson(res, { apps, running: [], runningIcons: {} }); return; }
  }

  if (p === '/api/rules' && req.method === 'GET') {
    sendJson(res, { rules }); return;
  }
  // ===== 微信文字模板（用户保存的） =====
  if (p === '/api/templates' && req.method === 'GET') {
    sendJson(res, { ok: true, templates }); return;
  }
  if (p === '/api/templates' && req.method === 'POST') {
    const body = await readBody(req);
    const t = body.template || body;
    const name = String((t && t.name) || '').trim();
    const text = String((t && t.text) || '');
    if (!name) { sendJson(res, { ok: false, error: '模板名称不能为空' }, 400); return; }
    if (!text.trim()) { sendJson(res, { ok: false, error: '模板内容不能为空' }, 400); return; }
    const id = t.id || ('t' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6));
    const rec = { id, name, text, updatedAt: Date.now() };
    const i = templates.findIndex(x => x.id === id);
    if (i >= 0) templates[i] = rec; else templates.push(rec);
    saveTemplates();
    sendJson(res, { ok: true, template: rec, templates }); return;
  }
  if (p.startsWith('/api/templates/') && req.method === 'DELETE') {
    const id = decodeURIComponent(p.slice('/api/templates/'.length));
    templates = templates.filter(x => x.id !== id);
    saveTemplates();
    sendJson(res, { ok: true, templates }); return;
  }
  if (p === '/api/rules' && req.method === 'POST') {
    const body = await readBody(req);
    const r = body.rule;
    if (!r || !r.id) { sendJson(res, { ok: false, error: '缺少规则' }, 400); return; }
    const idx = rules.findIndex(x => x.id === r.id);
    if (idx >= 0) rules[idx] = r; else rules.push(r);
    saveRules();
    sendJson(res, { ok: true, rules }); return;
  }
  if (p.startsWith('/api/rules/') && req.method === 'DELETE') {
    const id = decodeURIComponent(p.slice('/api/rules/'.length));
    rules = rules.filter(x => x.id !== id);
    delete logs[id];
    saveRules();
    sendJson(res, { ok: true, rules }); return;
  }

  if (p === '/api/run' && req.method === 'POST') {
    const body = await readBody(req);
    const rule = body.rule;
    if (!rule || !Array.isArray(rule.steps)) { sendJson(res, { ok: false, error: '缺少规则步骤' }, 400); return; }
    if (running.has(rule.id)) { sendJson(res, { ok: true, started: false, busy: true, ruleId: rule.id }); return; }
    enqueueRun(rule, 'manual'); // 进入全局串行队列，异步执行，前端轮询日志
    sendJson(res, { ok: true, started: true, ruleId: rule.id }); return;
  }
  if (p === '/api/stop' && req.method === 'POST') {
    const body = await readBody(req);
    // 仅当任务真的在执行或排队时才置停止标志，避免残留标志误取消下一次执行
    if (body.ruleId && (running.has(body.ruleId) || queued.has(body.ruleId))) stopFlags.add(body.ruleId);
    sendJson(res, { ok: true, stopped: true }); return;
  }
  if (p === '/api/run-step' && req.method === 'POST') {
    const body = await readBody(req);
    const step = body.step;
    if (!step) { sendJson(res, { ok: false, error: '缺少步骤' }, 400); return; }
    const ruleId = body.ruleId || 'preview';
    const result = await execStep(step, ruleId, 0);
    sendJson(res, { ok: result.ok, result }); return;
  }

  if (p === '/api/logs') {
    const ruleId = url.searchParams.get('ruleId');
    if (ruleId) sendJson(res, { logs: logs[ruleId] || [] });
    else sendJson(res, { logs });
    return;
  }
  if (p === '/api/logs/clear') {
    const ruleId = url.searchParams.get('ruleId');
    if (ruleId) delete logs[ruleId]; else Object.keys(logs).forEach(k => delete logs[k]);
    sendJson(res, { ok: true }); return;
  }

  if (p === '/api/scheduler' && req.method === 'GET') {
    sendJson(res, { running: !!schedTimer }); return;
  }
  if (p === '/api/scheduler' && req.method === 'POST') {
    const body = await readBody(req);
    if (body.action === 'start') startScheduler();
    else if (body.action === 'stop') stopScheduler();
    sendJson(res, { running: !!schedTimer }); return;
  }

  // 静态文件
  if (p === '/' || p === '/index.html' || p === '/agent-desktop-rule-builder.html') {
    try {
      const html = fs.readFileSync(HTML_FILE, 'utf8');
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache, no-store, must-revalidate' });
      res.end(html);
    } catch (e) { res.writeHead(404); res.end('HTML not found'); }
    return;
  }

  // 微信表情图片（wechat-emoji 目录）
  if (p.startsWith('/wechat-emoji/')) {
    const file = path.join(__dirname, p.replace(/^\//, ''));
    if (file.indexOf(__dirname) !== 0 || !fs.existsSync(file)) { res.writeHead(404); res.end('not found'); return; }
    const ext = path.extname(file).toLowerCase();
    const mime = ext === '.png' ? 'image/png' : ext === '.gif' ? 'image/gif' : ext === '.jpg' || ext === '.jpeg' ? 'image/jpeg' : ext === '.webp' ? 'image/webp' : 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': mime, 'Cache-Control': 'public, max-age=86400' });
    fs.createReadStream(file).pipe(res);
    return;
  }

  sendJson(res, { ok: false, error: 'not found' }, 404);
});

function openBrowser(url) {
  try {
    if (process.platform === 'win32') {
      spawn('cmd', ['/c', 'start', '', url], { stdio: 'ignore', detached: true }).unref();
    } else if (process.platform === 'darwin') {
      spawn('open', [url], { stdio: 'ignore', detached: true }).unref();
    } else {
      spawn('xdg-open', [url], { stdio: 'ignore', detached: true }).unref();
    }
  } catch (e) {}
}

server.listen(PORT, () => {
  console.log('Agent Desktop 规则调度服务已启动: http://localhost:' + PORT);
  startScheduler();
  if (process.env.AD_NO_BROWSER !== '1') {
    const url = 'http://localhost:' + PORT;
    setTimeout(() => openBrowser(url), 500);
  }
});
